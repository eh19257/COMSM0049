## -*- coding: utf-8 -*-
##
##  Jonathan Salwan - 2014-05-12 - ROPgadget tool
##
##  http://twitter.com/JonathanSalwan
##  http://shell-storm.org/project/ROPgadget/
##

import ropgadget.loaders.elf
import ropgadget.loaders.macho
import ropgadget.loaders.pe
import ropgadget.loaders.raw
